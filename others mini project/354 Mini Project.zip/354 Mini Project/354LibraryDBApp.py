import sqlite3
from datetime import datetime, timedelta
conn = sqlite3.connect('library.db')


def findItem(cur):
    myItemID = input("\nEnter the ID of the item to find. Press enter key to skip: ")
    myItemType = input("Enter the type of the item to find (print_book / online_book / magazine / journal / CD). Press enter key to skip: ")
    myItemTitle = input("Enter the title of the item to find. Press enter key to skip: ")
    myItemAuthor = input("Enter the author of the item to find. Press enter key to skip: ")
    myItemPublisher = input("Enter the publisher of the item to find. Press enter key to skip: ")

    myQuery = """
    SELECT * FROM Item
    WHERE itemID LIKE ? AND type LIKE ?
    AND (title LIKE ? OR title IS NULL)
    AND (author LIKE ? OR author IS NULL)
    AND (publisher LIKE ? OR publisher IS NULL)
    """
    cur.execute(myQuery, (f"%{myItemID}%", f"%{myItemType}%", f"%{myItemTitle}%", f"%{myItemAuthor}%", f"%{myItemPublisher}%"))

    rows=cur.fetchall()
    if rows:
        print("\nItems returned:")
    else:
        print("\nNo items found.\n")
        return

    for row in rows:
        print(row)
    print("\n")



def borrowItem(cur):
    myCustID = input("\nEnter your customer ID: ")
    checkQuery = "SELECT * FROM Customer WHERE custID = :myCustID"
    cur.execute(checkQuery, {"myCustID":myCustID})
    row = cur.fetchone()
    if not row:
        print("No customer found with ID " + myCustID + ".\n")
        return

    myItemID = input("Enter the ID of the item to borrow: ")
    checkQuery = "SELECT * FROM Item WHERE itemID = :myItemID"
    cur.execute(checkQuery, {"myItemID":myItemID})
    row = cur.fetchone()
    if not row:
        print("No item found with ID " + myCustID + ".\n")
        return

    myBorrowDate = datetime.today().date()
    returnDate = myBorrowDate + timedelta(days=7)

    myQuery = "INSERT INTO Borrows VALUES (:myCustID, :myItemID, :myBorrowDate)"
    cur.execute(myQuery, {"myCustID":myCustID, "myItemID":myItemID, "myBorrowDate":myBorrowDate})

    checkQuery = "SELECT * FROM Borrows WHERE custID = :myCustID AND itemID = :myItemID AND borrowDate = :myBorrowDate"
    cur.execute(checkQuery, {"myCustID":myCustID, "myItemID":myItemID, "myBorrowDate":myBorrowDate})

    rows = cur.fetchall()
    if rows:
        print("Borrowed item successfully. Please return it by " + str(returnDate) + ".\n")
    else:
        print("System Error: borrowing denied\n")



def returnItem(cur):
    myCustID = input("\nEnter your customer ID: ")
    checkQuery = "SELECT * FROM Customer WHERE custID = :myCustID"
    cur.execute(checkQuery, {"myCustID":myCustID})
    row = cur.fetchone()
    if not row:
        print("No customer found with ID " + myCustID + ".\n")
        return

    
    myItemID = input("Enter the ID of the item to return: ")
    checkQuery = "SELECT * FROM Borrows WHERE custID = :myCustID AND itemID = :myItemID"
    cur.execute(checkQuery, {"myCustID":myCustID, "myItemID":myItemID})
    row = cur.fetchone()
    if not row:
        print("No loan history found.\n")
        return

    identifyQuery = "SELECT borrowDate FROM Borrows WHERE custID = :myCustID AND itemID = :myItemID ORDER BY borrowDate DESC LIMIT 1"
    cur.execute(identifyQuery, {"myCustID":myCustID, "myItemID":myItemID})
    myBorrowDate = cur.fetchone()[0]
    myBorrowDate = datetime.strptime(myBorrowDate, "%Y-%m-%d").date()

    myReturnDate = datetime.today().date()
    returnDate = myBorrowDate + timedelta(days=7)
    
    # Execute return
    myQuery = "DELETE FROM Borrows WHERE custID = :myCustID AND itemID = :myItemID AND borrowDate = :myBorrowDate"
    cur.execute(myQuery, {"myCustID":myCustID, "myItemID":myItemID, "myBorrowDate":myBorrowDate})

    # Check if executed properly
    checkQuery = "SELECT * FROM Borrows WHERE custID = :myCustID AND itemID = :myItemID AND borrowDate = :myBorrowDate"
    cur.execute(checkQuery, {"myCustID":myCustID, "myItemID":myItemID, "myBorrowDate":myBorrowDate})

    rows = cur.fetchall()
    if rows:
        print("System Error: return denied\n")
    
    elif myReturnDate > returnDate:
        print("The return date has passed. Overdue fee charged.")
        libName = input("Enter the name of the library you are returning to: ")

        # Add to Overdue & Fine tables
        identifyQuery = "SELECT fineID FROM Overdue ORDER BY fineID DESC LIMIT 1"
        cur.execute(identifyQuery)
        myFineID = cur.fetchone() + 1

        myQuery = "INSERT INTO Overdue VALUES (:myCustID, :libName, :myFineID)"
        cur.execute(myQuery, {"myCustID":myCustID, "libName":libName, "myFineID":myFineID})

        myQuery = "INSERT INTO Fine VALUES (:myFineID, 5.00)"
        print("$5.00 charged.\n")


    else:
        print("Returned item successfully.\n")
    


def donateItem(cur):
    myItemType = input("\nEnter the type of the item to donate (print_book / online_book / magazine / journal / CD): ")
    myItemTitle = input("Enter the title of the item to donate: ")
    myItemAuthor = input("Enter the author of the item to donate: ")
    myItemPublisher = input("Enter the publisher of the item to donate: ")

    identifyQuery = "SELECT itemID FROM Item ORDER BY itemID DESC LIMIT 1"
    cur.execute(identifyQuery)
    myItemID = cur.fetchone()[0] + 1

    myQuery = "INSERT INTO Item VALUES (:myItemID, :myItemType, :myItemTitle, :myItemAuthor, :myItemPublisher)"
    cur.execute(myQuery, {"myItemID":myItemID, "myItemType":myItemType, "myItemTitle":myItemTitle, "myItemAuthor":myItemAuthor, "myItemPublisher":myItemPublisher})

    checkQuery = "SELECT * FROM Item WHERE itemID = :myItemID"
    cur.execute(checkQuery, {"myItemID":myItemID})

    row = cur.fetchone()
    if row:
        print("Donated item successfully. Thank you for your support!\n")
    else:
        print("System error: donation denied\n")



def findEvent(cur):
    myEventName = input("\nEnter the name of the event to find. Press enter key to skip: ")
    myEventDate = input("Enter the date of the event to find. Press enter key to skip: ")
    myEventAudience = input("Enter the target audience of the event to find. Press enter key to skip: ")
    myEventRoomNum = input("Enter the room number of the event to find. Press enter key to skip: ")

    myQuery = """
    SELECT * FROM Event
    WHERE name LIKE ? AND date LIKE ?
    AND (audience LIKE ? OR audience IS NULL)
    AND (roomNumber LIKE ? OR roomNumber IS NULL)
    """

    cur.execute(myQuery, (f"%{myEventName}%", f"%{myEventDate}%", f"%{myEventAudience}%", f"%{myEventRoomNum}%"))

    rows=cur.fetchall()
    if rows:
        print("\nEvents returned:")
    else:
        print("\nNo events found.\n")
        return

    for row in rows:
        print(row)
    print("\n")



def registerEvent(cur):
    myEventName = input("Enter the name of the event to register: ")
    checkQuery = "SELECT * FROM Event WHERE name = :myEventName"
    cur.execute(checkQuery, {"myEventName":myEventName})
    row = cur.fetchone()
    if not row:
        print("No events found with name " + myEventName + ".\n")
        return
    
    myEventDate = input("Enter the date of the event to register: ")
    checkQuery = "SELECT * FROM Event WHERE name = :myEventName AND date = :myEventDate"
    cur.execute(checkQuery, {"myEventName":myEventName, "myEventDate":myEventDate})
    row = cur.fetchone()
    if not row:
        print("No events found with name " + myEventName + " and date " + myEventDate + ".\n")
        return
    
    myCustID = input("Enter your customer ID: ")
    checkQuery = "SELECT * FROM Customer WHERE custID = :myCustID"
    cur.execute(checkQuery, {"myCustID":myCustID})
    row = cur.fetchone()
    if not row:
        print("No customer found with ID " + myCustID + ".\n")
        return

    myQuery = "INSERT INTO Attends VALUES (:myCustID, :myEventName, :myEventDate)"
    cur.execute(myQuery, {"myCustID":myCustID, "myEventName":myEventName, "myEventDate":myEventDate})

    checkQuery = "SELECT * FROM Attends WHERE custID = :myCustID AND eventName = :myEventName AND date = :myEventDate"
    cur.execute(checkQuery, {"myCustID":myCustID, "myEventName":myEventName, "myEventDate":myEventDate})

    row = cur.fetchone()
    if row:
        print("Registered successfully\n")
    else:
        print("System error: event registration denied\n")



def volunteer(cur):
    myName = input("Enter your name: ")
    myLibrary = input("Enter the name of the library to volunteer at: ")
    checkQuery = "SELECT * FROM Library WHERE name = :myLibrary"
    cur.execute(checkQuery, {"myLibrary":myLibrary})
    row = cur.fetchone()
    if not row:
        print("No library found with name " + myLibrary + ".\n")
        return
    
    # Generate the employee ID
    identifyQuery = "SELECT employeeID FROM Employee ORDER BY employeeID DESC LIMIT 1"
    cur.execute(identifyQuery)
    myEmployeeID = cur.fetchone()[0] + 1

    # Add to the employee list
    myQuery = "INSERT INTO Employee VALUES (:myEmployeeID, :myName, :myLibrary, 'volunteer')"
    cur.execute(myQuery, {"myEmployeeID":myEmployeeID, "myName":myName, "myLibrary":myLibrary})

    # Debug
    checkQuery = "SELECT * FROM Employee WHERE employeeID = :myEmployeeID AND name = :myName AND library = :myLibrary AND position = 'volunteer'"
    cur.execute(checkQuery, {"myEmployeeID":myEmployeeID, "myName":myName, "myLibrary":myLibrary})
    row = cur.fetchone()
    if row:
        print("Registered as a volunteer successfully. Welcome!\n")
    else:
        print("System error: volunteer registration denied\n")



def inquire(cur):
    # Get custID and inquiry summary
    myCustID = input("\nEnter your customer ID (5 digits): ")
    checkQuery = "SELECT * FROM Customer WHERE custID = :myCustID"
    cur.execute(checkQuery, {"myCustID":myCustID})
    row = cur.fetchone()
    if not row:
        print("No customer found with ID " + myCustID + ".\n")
        return

    myInquiry = input("Enter a brief summary of your inquiry: ")

    # Match any employee available
    identifyQuery = "SELECT employeeID FROM Employee ORDER BY RANDOM() LIMIT 1"
    cur.execute(identifyQuery)
    myEmployeeID = cur.fetchone()[0]

    # Assign the inquiry ID
    identifyQuery = "SELECT inquiryID FROM Inquiry ORDER BY inquiryID DESC LIMIT 1"
    cur.execute(identifyQuery)
    myInquiryID = cur.fetchone()[0] + 1

    # Insert values into tables
    myQuery = "INSERT INTO Helps VALUES (:myCustID, :myEmployeeID, :myInquiryID)"
    cur.execute(myQuery, {"myCustID":myCustID, "myEmployeeID":myEmployeeID, "myInquiryID":myInquiryID})

    myQuery = "INSERT INTO Inquiry VALUES (:myInquiryID, :myInquiry)"
    cur.execute(myQuery, {"myInquiryID":myInquiryID, "myInquiry":myInquiry})
    
    # Debug
    checkQuery = "SELECT * FROM Helps WHERE custID = :myCustID AND employeeID = :myEmployeeID AND inquiryID = :myInquiryID"
    cur.execute(checkQuery, {"myCustID":myCustID, "myEmployeeID":myEmployeeID, "myInquiryID":myInquiryID})
    row = cur.fetchone()
    if not row:
        print("System error: inquiry denied\n")
        return
    
    checkQuery = "SELECT * FROM Inquiry WHERE inquiryID = :myInquiryID AND summary = :myInquiry"
    cur.execute(checkQuery, {"myInquiryID":myInquiryID, "myInquiry":myInquiry})
    row = cur.fetchone()
    if row:
        print("Inquiry accepted successfully\n")
    else:
        print("System error: inquiry denied\n")



cursor = conn.cursor()
print("Opened database successfully \n")

with conn:

    cur = conn.cursor()

    print("1. Find an item in the library")
    print("2. Borrow an item from the library")
    print("3. Return a borrowed item")
    print("4. Donate an item to the library")
    print("5. Find an event in the library")
    print("6. Register for an event in the library")
    print("7. Volunteer for the library")
    print("8. Ask for help from a librarian")
    option = int(input("Which number of task would you like to perform?: "))

    options = {1: findItem,
               2: borrowItem,
               3: returnItem,
               4: donateItem,
               5: findEvent,
               6: registerEvent,
               7: volunteer,
               8: inquire,
    }

    options[option](cur)


if conn:
    conn.close()
    print("Closed database successfully")