import sqlite3
import random

# Connect to the database
conn = sqlite3.connect("library.db")
cursor = conn.cursor()

def find_item():
    """Find an item in the library by title or keyword."""
    title = input("Enter item title or keyword: ").strip()
    if not title:
        print("Invalid input. Please enter a valid title or keyword.")
        return
    cursor.execute("SELECT * FROM Item WHERE title LIKE ?", ('%' + title + '%',))
    results = cursor.fetchall()
    if results:
        for row in results:
            print(row)
    else:
        print("No items found.")

def borrow_item():
    """Borrow an item from the library."""
    user_id = input("Enter your user ID: ").strip()
    if not user_id.isdigit():
        print("Invalid user ID. Please enter a numeric value.")
        return
    cursor.execute("SELECT user_id FROM User WHERE user_id = ?", (user_id,))
    user_exists = cursor.fetchone()
    if not user_exists:
        print("Invalid user ID. Please try again.")
        return

    item_id = input("Enter the item ID to borrow: ").strip()
    if not item_id.isdigit():
        print("Invalid item ID. Please enter a numeric value.")
        return
    cursor.execute("SELECT availability FROM Item WHERE item_id = ?", (item_id,))
    status = cursor.fetchone()
    if status and status[0] == 'available':
        cursor.execute("""
            INSERT INTO Borrowing (user_id, item_id, borrow_date, due_date)
            VALUES (?, ?, DATE('now'), DATE('now', '+14 day'))
        """, (user_id, item_id))
        cursor.execute("UPDATE Item SET availability = 'borrowed' WHERE item_id = ?", (item_id,))
        conn.commit()
        print("Item borrowed successfully.")
    else:
        print("Item not available or does not exist.")

def return_item():
    """Return a borrowed item and calculate fines if overdue."""
    borrowing_id = input("Enter borrowing ID: ").strip()
    if not borrowing_id.isdigit():
        print("Invalid borrowing ID. Please enter a numeric value.")
        return

    # Check if the borrowing ID exists and if it already has a return date
    cursor.execute("""
        SELECT return_date, due_date, item_id, user_id
        FROM Borrowing
        WHERE borrowing_id = ?
    """, (borrowing_id,))
    borrowing = cursor.fetchone()
    if not borrowing:
        print("Invalid borrowing ID.")
        return

    return_date, due_date, item_id, user_id = borrowing
    if return_date:
        print("This item has already been returned.")
        return

    # Calculate the number of overdue days
    cursor.execute("""
        SELECT julianday('now') - julianday(?)
    """, (due_date,))
    days_late = cursor.fetchone()[0]
    fine = 0
    if days_late > 0:
        fine = round(days_late * 0.10, 2)  # Assuming $0.10 per day for overdue items

    # Update the Borrowing table with the return date and fine amount
    cursor.execute("""
        UPDATE Borrowing
        SET return_date = DATE('now'), fine_amount = ?
        WHERE borrowing_id = ?
    """, (fine, borrowing_id))

    # Mark the item as available
    cursor.execute("UPDATE Item SET availability = 'available' WHERE item_id = ?", (item_id,))
    conn.commit()

    print(f"Thank you, User ID {user_id}. Item returned successfully. Fine: ${fine:.2f}")

def donate_item():
    """Donate an item to the library."""
    title = input("Item title: ").strip()
    if not title:
        print("Invalid input. Please enter a valid title.")
        return

    type_ = input("Type (book, ebook, magazine, journal, CD, record): ").strip()
    if type_ not in ['book', 'ebook', 'magazine', 'journal', 'CD', 'record']:
        print("Invalid type. Please enter a valid type.")
        return

    user_id = input("Enter your user ID (leave blank if anonymous): ").strip()
    if user_id:
        if not user_id.isdigit():
            print("Invalid user ID. Please enter a numeric value.")
            return

        # Check if the user ID exists in the User table
        cursor.execute("SELECT user_id FROM User WHERE user_id = ?", (user_id,))
        user_exists = cursor.fetchone()
        if not user_exists:
            print("Invalid user ID. You must be a registered library member to donate an item.")
            return
    else:
        user_id = None  # Anonymous donation

    # Insert the donation into the FutureItem table
    cursor.execute("""
        INSERT INTO FutureItem (title, type, expected_arrival, status, user_id)
        VALUES (?, ?, DATE('now', '+7 day'), 'donation', ?)
    """, (title, type_, user_id))
    conn.commit()

    print("Thank you for donating! The item will be reviewed.")

def find_event():
    """Find an event in the library by name or keyword."""
    keyword = input("Search for event by name: ").strip()
    if not keyword:
        print("Invalid input. Please enter a valid keyword.")
        return
    cursor.execute("SELECT * FROM Event WHERE name LIKE ?", ('%' + keyword + '%',))
    results = cursor.fetchall()
    if results:
        for row in results:
            print(row)
    else:
        print("No events found.")

def register_event():
    """Register a user for an event."""
    user_id = input("Enter your user ID: ").strip()
    if not user_id.isdigit():
        print("Invalid user ID. Please enter a numeric value.")
        return
    cursor.execute("SELECT user_id FROM User WHERE user_id = ?", (user_id,))
    user_exists = cursor.fetchone()
    if not user_exists:
        print("Invalid user ID. Please try again.")
        return

    event_id = input("Enter the event ID: ").strip()
    if not event_id.isdigit():
        print("Invalid event ID. Please enter a numeric value.")
        return
    cursor.execute("SELECT event_id FROM Event WHERE event_id = ?", (event_id,))
    event_exists = cursor.fetchone()
    if not event_exists:
        print("Invalid event ID. Please try again.")
        return

    # Update the User table to associate the user with the event
    cursor.execute("""
        UPDATE User
        SET event_id = ?
        WHERE user_id = ?
    """, (event_id, user_id))
    conn.commit()
    print("Successfully registered for the event.")

def volunteer():
    """Volunteer for the library."""
    user_id = input("Enter your user ID: ").strip()
    if not user_id.isdigit():
        print("Invalid user ID. Please enter a numeric value.")
        return

    # Check if the user ID exists in the User table
    cursor.execute("SELECT user_id, name, email FROM User WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()
    if not user:
        print("Invalid user ID. You must be a registered library member to volunteer.")
        return

    user_name, user_email = user[1], user[2]

    # Check if the user is already linked to a Personnel record by matching email
    cursor.execute("SELECT personnel_id FROM Personnel WHERE email = ?", (user_email,))
    existing_personnel = cursor.fetchone()
    if existing_personnel:
        print(f"User ID {user_id} is already linked to Personnel ID {existing_personnel[0]}.")
        return

    # Insert the user into the Personnel table as a volunteer
    cursor.execute("""
        INSERT INTO Personnel (name, role, email)
        VALUES (?, 'volunteer', ?)
    """, (user_name, user_email))
    conn.commit()

    # Retrieve the newly created personnel_id
    cursor.execute("SELECT personnel_id FROM Personnel WHERE email = ?", (user_email,))
    personnel_id = cursor.fetchone()[0]

    # Update the User table with the new personnel_id
    cursor.execute("""
        UPDATE User
        SET personnel_id = ?
        WHERE user_id = ?
    """, (personnel_id, user_id))
    conn.commit()

    print(f"Thank you, {user_name}, for volunteering! Your Personnel ID is {personnel_id}.")

def ask_help():
    """Ask for help from a librarian or staff."""
    user_id = input("Enter your user ID: ").strip()
    if not user_id.isdigit():
        print("Invalid user ID. Please enter a numeric value.")
        return

    # Check if the user ID exists in the User table
    cursor.execute("SELECT name FROM User WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()
    if not user:
        print("Invalid user ID. You must be a registered library member to ask for help.")
        return

    user_name = user[0]

    # Retrieve a random personnel from the Personnel table
    cursor.execute("SELECT name, role FROM Personnel ORDER BY RANDOM() LIMIT 1")
    personnel = cursor.fetchone()
    if not personnel:
        print("No personnel available to assist you at the moment.")
        return

    personnel_name, role = personnel
    print(f"Thank you, {user_name}. {personnel_name}, one of our {role}s, is coming to help you soon.")

def menu():
    """Display the main menu and handle user choices."""
    while True:
        print("""
        ==== Library System ====
        1. Find an item
        2. Borrow an item
        3. Return an item
        4. Donate an item
        5. Find an event
        6. Register for an event
        7. Volunteer
        8. Ask for help
        9. Exit
        """)
        choice = input("Choose an option: ")
        if choice == '1':
            find_item()
        elif choice == '2':
            borrow_item()
        elif choice == '3':
            return_item()
        elif choice == '4':
            donate_item()
        elif choice == '5':
            find_event()
        elif choice == '6':
            register_event()
        elif choice == '7':
            volunteer()
        elif choice == '8':
            ask_help()
        elif choice == '9':
            break
        else:
            print("Invalid option. Try again.")

if __name__ == "__main__":
    menu()
    conn.close()