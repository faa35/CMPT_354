How to run it?

Just clone it to your repo

in VSCode terminal type

"python library_app.py" to test db on your own

OR

"python test_library_app.py" to run my test cases which includes edge cases as well

Thanks

Authors: Manan Gupta & Pritam Datta